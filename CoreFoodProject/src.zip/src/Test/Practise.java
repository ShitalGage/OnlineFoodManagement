package Test;

import java.time.LocalDateTime;
import java.util.Scanner;

public class Practise {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		LocalDateTime today=LocalDateTime.now();
		
		System.out.println("Current date and time"+today);
	}

}
